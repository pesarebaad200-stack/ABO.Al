package ir.aboai.features.travel

/** Integration boundary for the travel feature; implementation is intentionally staged. */
object Feature {
    const val ID = "travel"
    const val STATUS = "SCAFFOLDED_NOT_IMPLEMENTED"
}
