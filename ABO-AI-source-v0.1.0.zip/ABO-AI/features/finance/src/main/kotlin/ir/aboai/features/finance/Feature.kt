package ir.aboai.features.finance

/** Integration boundary for the finance feature; implementation is intentionally staged. */
object Feature {
    const val ID = "finance"
    const val STATUS = "SCAFFOLDED_NOT_IMPLEMENTED"
}
