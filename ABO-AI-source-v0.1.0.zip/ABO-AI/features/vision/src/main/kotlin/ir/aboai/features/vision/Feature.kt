package ir.aboai.features.vision

/** Integration boundary for the vision feature; implementation is intentionally staged. */
object Feature {
    const val ID = "vision"
    const val STATUS = "SCAFFOLDED_NOT_IMPLEMENTED"
}
