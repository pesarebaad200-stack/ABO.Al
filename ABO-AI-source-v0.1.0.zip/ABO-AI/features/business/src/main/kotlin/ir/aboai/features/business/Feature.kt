package ir.aboai.features.business

/** Integration boundary for the business feature; implementation is intentionally staged. */
object Feature {
    const val ID = "business"
    const val STATUS = "SCAFFOLDED_NOT_IMPLEMENTED"
}
