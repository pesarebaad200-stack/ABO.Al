package ir.aboai.features.home

/** Integration boundary for the home feature; implementation is intentionally staged. */
object Feature {
    const val ID = "home"
    const val STATUS = "SCAFFOLDED_NOT_IMPLEMENTED"
}
