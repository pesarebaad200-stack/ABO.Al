package ir.aboai.features.studio

/** Integration boundary for the studio feature; implementation is intentionally staged. */
object Feature {
    const val ID = "studio"
    const val STATUS = "SCAFFOLDED_NOT_IMPLEMENTED"
}
