package ir.aboai.features.tutor

/** Integration boundary for the tutor feature; implementation is intentionally staged. */
object Feature {
    const val ID = "tutor"
    const val STATUS = "SCAFFOLDED_NOT_IMPLEMENTED"
}
