package ir.aboai.features.agent

/** Integration boundary for the agent feature; implementation is intentionally staged. */
object Feature {
    const val ID = "agent"
    const val STATUS = "SCAFFOLDED_NOT_IMPLEMENTED"
}
