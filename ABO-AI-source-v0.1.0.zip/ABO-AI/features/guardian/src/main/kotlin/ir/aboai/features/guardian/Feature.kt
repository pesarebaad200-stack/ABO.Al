package ir.aboai.features.guardian

/** Integration boundary for the guardian feature; implementation is intentionally staged. */
object Feature {
    const val ID = "guardian"
    const val STATUS = "SCAFFOLDED_NOT_IMPLEMENTED"
}
