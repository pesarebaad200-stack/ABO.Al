package ir.aboai.features.camera

/** Integration boundary for the camera feature; implementation is intentionally staged. */
object Feature {
    const val ID = "camera"
    const val STATUS = "SCAFFOLDED_NOT_IMPLEMENTED"
}
