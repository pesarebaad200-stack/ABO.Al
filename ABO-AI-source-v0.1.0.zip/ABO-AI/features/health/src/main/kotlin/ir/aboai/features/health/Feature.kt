package ir.aboai.features.health

/** Integration boundary for the health feature; implementation is intentionally staged. */
object Feature {
    const val ID = "health"
    const val STATUS = "SCAFFOLDED_NOT_IMPLEMENTED"
}
