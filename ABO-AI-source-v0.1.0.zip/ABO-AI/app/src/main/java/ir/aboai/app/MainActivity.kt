package ir.aboai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ir.aboai.domain.ModuleCatalog

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ABOAIApp() }
    }
}

@Composable
private fun ABOAIApp() {
    MaterialTheme {
        Scaffold { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text("ABO AI", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                    Text("دستیار هوشمند شخصی", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = MaterialTheme.shapes.large) {
                        Column(Modifier.fillMaxWidth().padding(16.dp)) {
                            Text("نسخه اولیه", fontWeight = FontWeight.Bold)
                            Text("هسته رابط فارسی آماده است؛ اتصال هوش مصنوعی، دوربین و سرویس‌های ابری در فازهای بعدی افزوده می‌شوند.")
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("ماژول‌ها", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                }
                items(ModuleCatalog.all) { module ->
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text(module.titleFa, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(module.purposeFa, style = MaterialTheme.typography.bodyMedium)
                            if (module.requiresExplicitConsent) {
                                Text("نیازمند رضایت و کنترل دسترسی صریح", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
                item {
                    Text("حالت اتصال: Hybrid  •  کنترل Agent: Approval  •  دوربین: Pro", style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}
