pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories { google(); mavenCentral() }
}
rootProject.name = "ABO-AI"
include(":app", ":core:security", ":core:domain")
listOf("guardian", "agent", "vision", "camera", "tutor", "finance", "business", "studio", "health", "travel", "home").forEach { include(":features:$it") }
