package ir.aboai.security

/** The model may propose an action; only this deterministic policy layer can authorize it. */
enum class RiskLevel { LOW, SENSITIVE, EXTERNAL_OR_IRREVERSIBLE }
enum class Decision { ALLOW, REQUIRE_USER_APPROVAL, DENY }

data class ActionRequest(
    val action: String,
    val risk: RiskLevel,
    val userApproved: Boolean = false,
    val requiredPermissionGranted: Boolean = false
)

object ActionPolicy {
    fun evaluate(request: ActionRequest): Decision {
        if (request.action.isBlank()) return Decision.DENY
        if (request.risk == RiskLevel.EXTERNAL_OR_IRREVERSIBLE && !request.userApproved) {
            return Decision.REQUIRE_USER_APPROVAL
        }
        if (request.risk != RiskLevel.LOW && !request.requiredPermissionGranted) {
            return Decision.DENY
        }
        if (request.risk == RiskLevel.EXTERNAL_OR_IRREVERSIBLE && request.userApproved) return Decision.ALLOW
        return Decision.ALLOW
    }
}
