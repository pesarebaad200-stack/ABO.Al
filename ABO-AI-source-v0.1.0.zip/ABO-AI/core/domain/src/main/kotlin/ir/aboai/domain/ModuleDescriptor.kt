package ir.aboai.domain

enum class ModuleId { GUARDIAN, AGENT, VISION, CAMERA, TUTOR, FINANCE, BUSINESS, STUDIO, HEALTH, TRAVEL, HOME }

data class ModuleDescriptor(
    val id: ModuleId,
    val titleFa: String,
    val purposeFa: String,
    val requiresExplicitConsent: Boolean = false
)

object ModuleCatalog {
    val all = listOf(
        ModuleDescriptor(ModuleId.GUARDIAN, "ABO Guardian", "مرکز امنیت، مجوزها و حریم خصوصی"),
        ModuleDescriptor(ModuleId.AGENT, "ABO Agent", "اجرای وظایف با سیاست تأیید کاربر"),
        ModuleDescriptor(ModuleId.VISION, "ABO Vision", "درک و تحلیل تصویر و محیط"),
        ModuleDescriptor(ModuleId.CAMERA, "ABO Camera Pro", "ثبت تصویر و کنترل دوربین دستگاه"),
        ModuleDescriptor(ModuleId.TUTOR, "ABO Tutor", "یادگیری، آموزش و تمرین"),
        ModuleDescriptor(ModuleId.FINANCE, "ABO Finance", "ابزارهای مالی با حفاظت از داده حساس", true),
        ModuleDescriptor(ModuleId.BUSINESS, "ABO Business", "ابزارهای کسب‌وکار و تحلیل"),
        ModuleDescriptor(ModuleId.STUDIO, "ABO Studio", "تولید و مدیریت محتوای خلاقانه"),
        ModuleDescriptor(ModuleId.HEALTH, "ABO Health", "اطلاعات سلامت با رضایت صریح", true),
        ModuleDescriptor(ModuleId.TRAVEL, "ABO Travel", "برنامه‌ریزی سفر"),
        ModuleDescriptor(ModuleId.HOME, "ABO Home", "یکپارچه‌سازی خانه هوشمند با تأیید", true)
    )
}
