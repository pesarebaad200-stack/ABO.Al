# ABO AI — Android starter (v0.1.0)

A Persian-first, modular Android project scaffold based on the approved ABO AI decisions.

## Included now
- Android app shell using Kotlin and Jetpack Compose.
- Persian RTL-friendly module dashboard with all 11 selected modules.
- Separate domain catalog and deterministic security policy core.
- 11 isolated feature modules with explicit scaffold status.
- Product decision record and staged roadmap.

## Not implemented yet
No LLM/provider connection, speech pipeline, camera capture/control, image inference, cloud sync, finance/health integrations, smart-home control, authentication, encrypted persistence, or production-grade consent screens are implemented. Feature module markers intentionally say `SCAFFOLDED_NOT_IMPLEMENTED`.

## Build
Requires Android Studio or a machine with JDK 17+, Android SDK platform 35, and Gradle 8.9+ (AGP 8.7.3). Open this directory in Android Studio and sync Gradle, then run `:app:assembleDebug`.

This environment did not contain Android SDK or Gradle, so no APK build is claimed.
