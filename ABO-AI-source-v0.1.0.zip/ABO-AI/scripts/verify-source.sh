#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mods=(guardian agent vision camera tutor finance business studio health travel home)
[[ -f "$ROOT/settings.gradle.kts" ]]
[[ -f "$ROOT/app/src/main/AndroidManifest.xml" ]]
[[ -f "$ROOT/app/src/main/java/ir/aboai/app/MainActivity.kt" ]]
[[ -f "$ROOT/core/security/src/main/kotlin/ir/aboai/security/ActionPolicy.kt" ]]
[[ -f "$ROOT/core/domain/src/main/kotlin/ir/aboai/domain/ModuleDescriptor.kt" ]]
for m in "${mods[@]}"; do
  [[ -f "$ROOT/features/$m/build.gradle.kts" ]]
  [[ -f "$ROOT/features/$m/src/main/kotlin/ir/aboai/features/$m/Feature.kt" ]]
done
python3 - "$ROOT/app/src/main/AndroidManifest.xml" <<'PY'
import sys, xml.etree.ElementTree as ET
ET.parse(sys.argv[1])
print('Manifest XML: valid')
PY
[[ "$(grep -c 'ModuleDescriptor(ModuleId\.' "$ROOT/core/domain/src/main/kotlin/ir/aboai/domain/ModuleDescriptor.kt")" -eq 11 ]]
grep -q 'EXTERNAL_OR_IRREVERSIBLE' "$ROOT/core/security/src/main/kotlin/ir/aboai/security/ActionPolicy.kt"
grep -q 'REQUIRE_USER_APPROVAL' "$ROOT/core/security/src/main/kotlin/ir/aboai/security/ActionPolicy.kt"
grep -q 'SCAFFOLDED_NOT_IMPLEMENTED' "$ROOT/features/agent/src/main/kotlin/ir/aboai/features/agent/Feature.kt"
echo 'Source structure: valid; 11 feature modules present; approval gate present.'
